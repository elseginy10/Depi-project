# DEPI-Project
This repository contains a comprehensive data analysis project on HR dataset. The analysis aims to uncover insights, patterns, and trends within the dataset to answer key questions and support data-driven decision-making.
